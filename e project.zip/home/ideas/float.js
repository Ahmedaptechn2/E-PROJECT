// Float Animation Script
gsap.registerPlugin(ScrollTrigger);

const tl = gsap.timeline({
    scrollTrigger: {
        trigger: ".jeton-wrapper",
        start: "top top",
        end: "+=200%",
        scrub: 1,
        pin: true
    }
});

// Text zoom out
tl.from(".big-text h1", {
    scale: 20,
    opacity: 0,
    duration: 3,
    ease: "power2.out"
});

// Cards fly in
tl.from(".card-0", { y: "150vh", rotationX: -45, opacity: 0, duration: 3 }, "-=2.5");
tl.from(".card-1", { x: "-120vw", rotation: -30, opacity: 0, duration: 3 }, "-=2.5");
tl.from(".card-2", { x: "120vw", rotation: 30, opacity: 0, duration: 3 }, "-=2.5");
tl.from(".card-3", { y: "-150vh", scale: 2, opacity: 0, duration: 3, ease: "back.out(1.7)" }, "-=2.5");

// Stacking
tl.to(".card-0", {
    y: -45, scale: 0.85, rotationX: 0, filter: "brightness(0.3)", duration: 1
}, "stack");

tl.to(".card-1", {
    y: -30, scale: 0.90, rotation: 0, x: 0, filter: "brightness(0.5)", duration: 1
}, "stack");

tl.to(".card-2", {
    y: -15, scale: 0.95, rotation: 0, x: 0, filter: "brightness(0.7)", duration: 1
}, "stack");

tl.to(".card-3", {
    y: 0, scale: 1, rotation: 0, boxShadow: "0 10px 60px rgba(57, 255, 20, 0.4)", duration: 1
}, "stack");
